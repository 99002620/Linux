#ifndef __MYUTILS_H
#define __MYUTILS_H
int factorial(int);
int isprime(int);
int ispalindrome(int);
int sum(int arg_count,...);
#endif

