#ifndef MYSTRING_H_INCLUDED
#define MYSTRING_H_INCLUDED

 

unsigned int my_strlen(char *p);
char *my_strcpy(char *destination, char *source);
char *my_strcat(char *strg1, char *strg2);
int my_strcmp(char *strg1, char *strg2);

 

#endif // MYSTRING_H_INCLUDED
